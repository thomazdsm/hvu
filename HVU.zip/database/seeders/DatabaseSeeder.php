<?php

namespace Database\Seeders;

use App\Models\ProcessStep;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
//        $this->call(RolesTableSeeder::class);
//        $this->command->info('Roles Seed executado com sucesso!');

//        $this->call(SpeciesTableSeeder::class);
//        $this->command->info('Species Seed executado com sucesso!');

//        $this->call(ProcessStepTableSeeder::class);
//        $this->command->info('ProcessSteps Seed executado com sucesso!');
    }
}
